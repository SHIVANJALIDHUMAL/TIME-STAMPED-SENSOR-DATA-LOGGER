#include "display.h"     // Display function prototypes
#include "lcd.h"         // LCD driver functions
#include "uart.h"        // UART driver functions
#include "rtc.h"         // RTC driver functions
#include "defines.h"     // Bit manipulation macros
#include "lpc21xx.h"     // LPC21xx MCU register definitions

extern s32 set_point;    // External temperature set-point variable

/* Week day strings for displaying day on LCD */
static char week[][4] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};


/*------------------------------------------------
  Display Time, Date, Day and Temperature
------------------------------------------------*/
void Display_Data(s32 temp)
{
    s32 hour, min, sec;        // Variables to store time
    s32 date, month, year;    // Variables to store date
    s32 day;                  // Variable to store day of week
	
	  SetRTCTimeInfo(10,10,00);     // Set initial time
    SetRTCDateInfo(07,01,26);    // Set initial date
    SetRTCDay(2);           // Set day

	
    static s32 prev_min = -1; // Stores previous minute for UART logging

    /* Get current time from RTC */
    GetRTCTimeInfo(&hour, &min, &sec);

    /* Get current date from RTC */
    GetRTCDateInfo(&date, &month, &year);

    /* Get current day from RTC */
    GetRTCDay(&day);
	
    /* Move LCD cursor to first line */
    CmdLCD(0x80);

    /* Display hour */
    CharLCD(hour / 10 + '0');
    CharLCD(hour % 10 + '0');
    CharLCD(':');

    /* Display minute */
    CharLCD(min / 10 + '0');
    CharLCD(min % 10 + '0');
    CharLCD(':');

    /* Display second */
    CharLCD(sec / 10 + '0');
    CharLCD(sec % 10 + '0');
    CharLCD(' ');

    /* Display day string */
    StrLCD(week[day]);

    /* Move LCD cursor to second line */
    CmdLCD(0xC0);

    /* Display date */
    CharLCD(date / 10 + '0');
    CharLCD(date % 10 + '0');
    CharLCD('/');

    /* Display month */
    CharLCD(month / 10 + '0');
    CharLCD(month % 10 + '0');
    CharLCD('/');

    /* Display last two digits of year */
    CharLCD((year % 100) / 10 + '0');
    CharLCD((year % 100) % 10 + '0');
    CharLCD(' ');

    /* Display temperature label */
    CharLCD('T');
    CharLCD(':');

    /* Display temperature value */
    IntLCD(temp);

    /* Display degree symbol and unit */
    CharLCD(0xDF);        
    CharLCD('C');
		
    /* Send UART log only when minute changes */
    if (min != prev_min)
    {
        prev_min = min;

        UARTTxStr("[INFO] Temp:");
        UARTTxu32(temp);
        UARTTxStr("C @ ");

        /* Send time over UART */
        if (hour < 10) UARTTxChar('0');
        UARTTxu32(hour);
        UARTTxChar(':');

        if (min < 10) UARTTxChar('0');
        UARTTxu32(min);
        UARTTxChar(':');

        if (sec < 10) UARTTxChar('0');
        UARTTxu32(sec);

        UARTTxStr(" ");

        /* Send date over UART */
        if (date < 10) UARTTxChar('0');
        UARTTxu32(date);
        UARTTxChar('/');

        if (month < 10) UARTTxChar('0');
        UARTTxu32(month);
        UARTTxChar('/');

        UARTTxu32(year);
    }
}
