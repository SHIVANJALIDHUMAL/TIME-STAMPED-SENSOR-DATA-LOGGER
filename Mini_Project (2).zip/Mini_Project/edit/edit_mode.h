void edit_mode(void);
#define UP_ARROW_CHAR    0
#define DOWN_ARROW_CHAR  1
