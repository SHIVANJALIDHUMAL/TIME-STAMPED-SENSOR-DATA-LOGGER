#include <lpc21xx.h>     // LPC21xx register definitions
#include "types.h"      // Custom data types
#include "lcd.h"        // LCD driver
#include "keypad.h"     // Keypad driver
#include "rtc.h"        // RTC registers/macros
#include "uart.h"       // UART driver
#include "delay.h"      // Delay utilities
#include "edit_mode.h"  // Edit mode prototypes
#include "defines.h"    // Bit macros

#define SWITCH_PIN   15   // Edit mode switch input pin

/* External Global Variables */
extern s32 set_point;     // Temperature set-point
extern u8  edit_flag;     // Edit mode flag

/* Local Variables */
u8  choice;
s32 temp, d, m, y, flg = 0;

/* Local Function Prototypes */
static void edit_rtc(void);
static void edit_set_point(void);
static int  set_multi(u8 *str);

/*-----------------------------------------
  Enter Edit Mode (Main Menu)
-----------------------------------------*/
void edit_mode(void)
{
    /* Stay in edit mode while switch is pressed */
    while ((READBIT(IOPIN0, SWITCH_PIN)) == 0)
    {
        /* Display Edit Menu */
        CmdLCD(0x01);
        CmdLCD(0x80);
        StrLCD("1.EDIT RTC");

        CmdLCD(0xC0);
        StrLCD("2.E.ST 3.EX");

        WRITENIBBLE(IOPIN1, 24, 0x0);   // Clear keypad input area
        while (ColStat());            // Wait for key press

        choice = KeyVal();            // Read keypad choice

        switch (choice)
        {
            case '1':   // Edit RTC
                edit_rtc();
                break;

            case '2':   // Edit Set Point
                edit_set_point();
                break;

            case '3':   // Exit Edit Mode
                CmdLCD(0x01);
                StrLCD("EXITING...");
                delay_ms(800);
                edit_flag = 0;
                UARTTxStr("*** EXIT EDIT MODE ***\r\n");
                return;
        }
    }
}

/*-----------------------------------------
  Multi-Digit Number Entry Using Keypad
  '*' = Enter / Confirm
  '+' = Backspace
-----------------------------------------*/
static int set_multi(u8 *str)
{
    u32 Value1 = 0, Value2 = 0, i;

    while (1)
    {
        WRITENIBBLE(IOPIN1, 24, 0x0);
        CmdLCD(0x80);                 // Go to first line

        /* Display Prompt String */
        for (i = 0; i < str[i]; i++)
            CharLCD(str[i]);

        while (ColStat());           // Wait for key press
        Value1 = KeyVal();           // Read key

        if (Value1 == '*')           // Confirm entry
        {
            return Value2;
        }
        else if (Value1 == '+')      // Backspace
        {
            Value2 = Value2 / 10;
            CmdLCD(0x01);
            CmdLCD(0xC0);
            IntLCD(Value2);
        }
        else                         // Numeric entry
        {
            if (Value2 < 9999)
            {
                Value2 = Value2 * 10 + (Value1 - '0');
                CmdLCD(0xC0);
                IntLCD(Value2);
            }
        }
    }
}

/*-----------------------------------------
  Edit RTC Parameters (Time & Date)
-----------------------------------------*/
static void edit_rtc(void)
{
    s32 value;

    while (1)
    {
        /* RTC Edit Menu */
        CmdLCD(0x01);
        CmdLCD(0x80);
        StrLCD("1H 2M 3S 4D");
        CmdLCD(0xC0);
        StrLCD("5DT 6MN 7YR 8E");

        WRITENIBBLE(IOPIN1, 24, 0x0);
        while (ColStat());
        choice = KeyVal();

        switch (choice)
        {
            case '1':   // Hour
                CmdLCD(0x01);
                value = set_multi("SET HOUR(0-23)");
                if (value <= 23)
                    HOUR = value;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_s(1);
                }
                break;

            case '2':   // Minute
                CmdLCD(0x01);
                value = set_multi("SET MIN(0-59)");
                if (value <= 59)
                    MIN = value;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_s(1);
                }
                break;

            case '3':   // Second
                CmdLCD(0x01);
                value = set_multi("SET SEC(0-59)");
                if (value <= 59)
                    SEC = value;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_s(1);
                }
                break;

            case '4':   // Day of Week
                CmdLCD(0x01);
                value = set_multi("SET DAY(0-6)");
                if (value <= 6)
                    DOW = value;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_s(1);
                }
                break;

            case '5':   // Date
                CmdLCD(0x01);
                value = set_multi("SET DATE(1-31)");
                if (value >= 1 && value <= 31)
                    DOM = value;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_s(1);
                }
                break;

            case '6':   // Month
                CmdLCD(0x01);
                value = set_multi("SET MONTH(1-12)");
                if (value >= 1 && value <= 12)
                    MONTH = value;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_s(1);
                }
                break;

            case '7':   // Year
                CmdLCD(0x01);
                value = set_multi("SET YEAR");
                if (value <= 4095)
                    YEAR = value;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_s(1);
                }
                break;

            case '8':   // Exit RTC Edit
                CmdLCD(0x01);
                StrLCD("RTC UPDATED");
                delay_ms(800);
                return;
        }
    }
}

/*-----------------------------------------
  Edit Temperature Set-Point
-----------------------------------------*/
static void edit_set_point(void)
{
    s32 value;

    CmdLCD(0x01);
    value = set_multi("SET TEMP(30-80)");

    if (value >= 30 && value <= 80)
    {
        set_point = value;
        CmdLCD(0x01);
        StrLCD("SETPOINT OK");
    }
    else
    {
        CmdLCD(0x01);
        StrLCD("INVALID VALUE");
    }

    delay_ms(800);
}
