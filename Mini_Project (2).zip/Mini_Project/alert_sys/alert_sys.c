#include "types.h"        // Custom data types like s32
#include "lpc21xx.h"     // LPC21xx MCU register definitions
#include "uart.h"        // UART driver functions
#include "rtc.h"         // RTC driver functions

#define ALERT_PIN    16   // Buzzer / alert output pin
#define LED_PIN      17   // Status LED output pin

extern s32 set_point;    // External temperature set-point variable

/*------------------------------------------------
  Temperature Alert System
  Turns ON LED + ALERT if temperature > set_point
------------------------------------------------*/
void temp_alert(s32 temperature)
{
    s32 hour, min, sec;        // Variables to store time
    s32 date, month, year;    // Variables to store date
    s32 day;                  // Variable to store day of week

    /* Configure LED and ALERT pins as OUTPUT */
    IODIR0 |= (1<<LED_PIN) | (1<<ALERT_PIN);

    /* Get current time from RTC */
    GetRTCTimeInfo(&hour, &min, &sec);

    /* Get current date from RTC */
    GetRTCDateInfo(&date, &month, &year);

    /* Get current day from RTC */
    GetRTCDay(&day);

    /* Check if temperature exceeds set-point */
    if (temperature > set_point)
    {
        /* Turn ON LED and ALERT */
        IOSET0 = (1<<LED_PIN) | (1<<ALERT_PIN);

        /* Send alert message over UART */
        UARTTxStr("[ALERT] Over Temperature: ");
        UARTTxu32(temperature);
        UARTTxStr("C @ ");

        /* Send time */
        if (hour < 10) UARTTxChar('0');
        UARTTxu32(hour);
        UARTTxChar(':');

        if (min < 10) UARTTxChar('0');
        UARTTxu32(min);
        UARTTxChar(':');

        if (sec < 10) UARTTxChar('0');
        UARTTxu32(sec);
        UARTTxStr(" ");

        /* Send date */
        if (date < 10) UARTTxChar('0');
        UARTTxu32(date);
        UARTTxChar('/');

        if (month < 10) UARTTxChar('0');
        UARTTxu32(month);
        UARTTxChar('/');

        UARTTxu32(year);
        UARTTxStr("\r\n");
    }
    else
    {
        /* Turn OFF LED and ALERT if temperature is normal */
        IOCLR0 = (1<<LED_PIN) | (1<<ALERT_PIN);
    }
}
