void temp_alert(int temperature);
