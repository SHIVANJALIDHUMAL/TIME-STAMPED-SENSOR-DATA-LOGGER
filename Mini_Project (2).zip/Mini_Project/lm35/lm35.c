#include"types.h"        // Custom data types like u8, u32, f32
#include"adc.h"          // ADC driver functions
#include"adc_defines.h"  // ADC channel definitions
#include"lm35.h"         // LM35 function prototype

/*------------------------------------------------
  LM35 Temperature Sensor Reading using ADC
------------------------------------------------*/

/* Function to read temperature in Celsius and Fahrenheit using pointers
void Read_LM35(f32 *tdegc, f32 *tdegf)
{
	u32 adcDVal;              // Raw ADC digital value
	f32 eAR;                 // Equivalent Analog Reading (voltage)

	Read_ADC(CH0, &eAR, &adcDVal);  // Read ADC channel connected to LM35

	*tdegc = eAR*100;        // Convert voltage to Celsius (10mV/�C)
	*tdegf = ((*tdegc *(9/5.0))+32); // Convert Celsius to Fahrenheit
}
*/

/* Function to return temperature based on type (C/F)
f32 Read_LM35(u8 tType)
{
	u32 adcDVal;            // Raw ADC digital value
	f32 eAR, tDeg;         // Voltage and temperature

	Read_ADC(CH0, &eAR, &adcDVal);  // Read ADC channel

	tDeg = eAR *100;       // Convert voltage to Celsius

	if(tType == 'C');      // If Celsius, do nothing
	else if(tType == 'F')  // If Fahrenheit
		tDeg = ((tDeg * (9/5.0))+32); // Convert to Fahrenheit

	return tDeg;          // Return temperature
}
*/

/* Function to read temperature in Celsius or Fahrenheit */
f32 Read_LM35(u8 tType)
{
    u32 adcDVal;     // Holds raw ADC digital value
    f32 eAR;         // Holds equivalent analog voltage
    f32 tDeg;        // Holds temperature value

    /* Read ADC Channel 0 connected to LM35 sensor */
    Read_ADC(CH0, &eAR, &adcDVal);

    /* Convert voltage to temperature in Celsius
       LM35 gives 10mV per �C ? 0.01V/�C */
    tDeg = eAR * 100.0f;   

    /* If Fahrenheit is requested, convert from Celsius */
    if (tType == 'F')
    {
        tDeg = (tDeg * 9.0f / 5.0f) + 32.0f;   
    }

    return tDeg;   // Return temperature value
}
