#include"types.h"
//void Read_LM35(f32 *tdegc, f32 *tdegf);
f32 Read_LM35(u8 tType);
