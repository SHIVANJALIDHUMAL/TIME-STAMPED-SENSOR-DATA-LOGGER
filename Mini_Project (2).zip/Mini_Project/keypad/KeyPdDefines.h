#include<LPC21xx.h>
#include"types.h"
#define R0 24   //p1.24
#define R1 25
#define R2 26
#define R3 27
#define C0 28
#define C1 29
#define C2 30
#define C3 31     //p1.31


u8 LUT[][4]={'7','8','9','/',
	           '4','5','6','*',
						 '1','2','3','-',
	           'C','0','=','+'};

