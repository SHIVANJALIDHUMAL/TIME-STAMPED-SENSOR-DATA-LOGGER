#include"types.h"
void KeyPdInit(void);
u8 ColStat(void);
u8 KeyVal(void);
s32 GetMultiDigit(void);


