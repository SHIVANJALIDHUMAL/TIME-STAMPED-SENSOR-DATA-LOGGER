#include <LPC21XX.h>       // LPC21xx register definitions
#include "types.h"        // Custom types like s8
#include "KeyPdDefines.h" // Row/Column pin macros + LUT

/*-----------------------------------------
  Initialize Keypad GPIO Pins
-----------------------------------------*/
void KeyPdInit(void)
{
    /* Set Row pins as OUTPUT */
    IODIR1 |= (1<<R0) | (1<<R1) | (1<<R2) | (1<<R3);
    /* Column pins remain as INPUT by default */
}

/*-----------------------------------------
  Check Column Status
  Returns 1 if NO key is pressed
-----------------------------------------*/
int ColStat(void)
{
    /* Read 4 column bits and check if all are HIGH (no key pressed) */
    if(((IOPIN1 >> C0) & 0x0F) == 0x0F)
    {
        return 1;   // No key pressed
    }
    return 0;       // Some key is pressed
}

/*-----------------------------------------
  Get Pressed Key Value
-----------------------------------------*/
char KeyVal(void)
{
    s8 rowval, colval;

    /* Activate Row 0 (make it LOW), others HIGH */
    IOCLR1 = (1<<R0);
    IOSET1 = (1<<R1) | (1<<R2) | (1<<R3);
    if(((IOPIN1 >> C0) & 0x0F) != 0x0F)
    {
        rowval = 0;
        goto colcheck;
    }

    /* Activate Row 1 */
    IOCLR1 = (1<<R1);
    IOSET1 = (1<<R0) | (1<<R2) | (1<<R3);
    if(((IOPIN1 >> C0) & 0x0F) != 0x0F)
    {
        rowval = 1;
        goto colcheck;
    }

    /* Activate Row 2 */
    IOCLR1 = (1<<R2);
    IOSET1 = (1<<R0) | (1<<R1) | (1<<R3);
    if(((IOPIN1 >> C0) & 0x0F) != 0x0F)
    {
        rowval = 2;
        goto colcheck;
    }

    /* Activate Row 3 */
    IOCLR1 = (1<<R3);
    IOSET1 = (1<<R0) | (1<<R1) | (1<<R2);
    if(((IOPIN1 >> C0) & 0x0F) != 0x0F)
    {
        rowval = 3;
        goto colcheck;
    }

colcheck:
    /* Identify which column is LOW */
    if(((IOPIN1 >> C0) & 1) == 0)
        colval = 0;
    else if(((IOPIN1 >> C1) & 1) == 0)
        colval = 1;
    else if(((IOPIN1 >> C2) & 1) == 0)
        colval = 2;
    else
        colval = 3;

    /* Wait until key is released (debounce handling) */
    while(((IOPIN1 >> C0) & 0x0F) != 0x0F);

    /* Return key from Look-Up Table */
    return LUT[rowval][colval];
}
