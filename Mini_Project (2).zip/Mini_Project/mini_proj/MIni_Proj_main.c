#include <LPC21xx.h>       // LPC21xx MCU register definitions
#include "types.h"        // Custom data types (u8, s32, etc.)
#include "rtc.h"          // RTC driver
#include "lcd.h"          // LCD driver
#include "uart.h"         // UART driver
#include "delay.h"        // Delay utilities
#include "keypad.h"       // Keypad driver
#include "edit_mode.h"    // Edit mode functions
#include "lm35.h"         // LM35 temperature sensor driver
#include "display.h"      // LCD display formatting
#include "adc.h"          // ADC driver
#include "adc_defines.h"  // ADC channel definitions
#include "defines.h"      // Bit macros
#include "alert_sys.h"    // Temperature alert system

/*---------------- PIN DEFINITIONS ----------------*/
#define SWITCH_PIN   15    // Mode switch input pin
#define ALERT_PIN    16    // Buzzer / alert output pin
#define LED_PIN      17    // Status LED output pin

/*---------------- GLOBAL VARIABLES ----------------*/
s32 set_point = 45;       // Temperature set-point (�C)
u8  edit_flag = 0;        // Edit mode status flag

/*---------------- MAIN FUNCTION ----------------*/
int main(void)
{
    s32 temperature;     // Stores current temperature reading

    /* Initialize Peripherals */
    InitUART();          // Initialize UART for serial logging
    InitLCD();           // Initialize LCD display
    RTC_Init();          // Initialize RTC
    Init_ADC(CH1);       // Initialize ADC on channel 1
    KeyPdInit();         // Initialize keypad GPIO

    /* Configure ALERT and LED pins as OUTPUT */
    IODIR0 |= (1 << ALERT_PIN) | (1 << LED_PIN); 
     
    /* Set Initial RTC Time and Date */
    SetRTCTimeInfo(10, 10, 00);   // HH:MM:SS
    SetRTCDateInfo(07, 01, 26);   // DD/MM/YY
    //SetRTCDay("TUE");          // Optional: Set day

    /* Send startup message over UART */
    UARTTxStr("\r\nTIME-STAMPED SENSOR LOGGER STARTED\r\n");

    /*---------------- MAIN LOOP ----------------*/
    while (1)
    {
        temperature = Read_LM35('C');   // Read temperature in Celsius
        Display_Data(temperature);     // Display temperature on LCD
        temp_alert(temperature);       // Check for over-temperature alert
        edit_mode();                   // Handle keypad-based edit mode
    }
}
