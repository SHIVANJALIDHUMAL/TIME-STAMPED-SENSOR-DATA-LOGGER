#include"types.h"
void InitLCD(void);
void CmdLCD(u8);
void CharLCD(u8);	
void DispLCD(u8);
void IntLCD(s32 num);
void FltLCD(f32 val);
void StrLCD(u8 *ptr);
void StoreCustCharFont(void);


