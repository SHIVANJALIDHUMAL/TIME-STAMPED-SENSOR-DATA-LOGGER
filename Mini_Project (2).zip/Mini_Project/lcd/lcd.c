#include <LPC21xx.h>     // LPC21xx register definitions
#include "delay.h"      // Delay functions
#include "lcd.h"        // LCD function prototypes
#include "types.h"      // Custom data types
#include "defines.h"    // Bit macros

/*---------------- PIN DEFINITIONS ----------------*/
// LCD Data Lines D0�D7 connected to P1.16�P1.23
#define LCD_DAT (0xFF << 16)

// LCD Control Pins
#define RS 11   // Register Select: P0.11
#define RW 12   // Read/Write:      P0.12
#define EN 13   // Enable:          P0.13

/*---------------- LCD INITIALIZATION ----------------*/
void InitLCD(void)
{
    /* Configure data pins as OUTPUT */
    IODIR1 |= LCD_DAT;

    /* Configure control pins as OUTPUT */
    IODIR0 |= (1 << RS) | (1 << RW) | (1 << EN);

    delay_ms(20);  // Wait for LCD power-up

    /* LCD Reset Sequence */
    CmdLCD(0x30);
    delay_ms(10);
    CmdLCD(0x30);
    delay_ms(1);
    CmdLCD(0x30);
    delay_ms(1);

    /* LCD Configuration */
    CmdLCD(0x38);   // 8-bit, 2-line, 5x7 font
    CmdLCD(0x08);   // Display OFF
    CmdLCD(0x01);   // Clear display
    delay_ms(2);
    CmdLCD(0x06);   // Entry mode: cursor moves right
    CmdLCD(0x0F);   // Display ON, cursor ON, blink ON
}

/*---------------- SEND COMMAND TO LCD ----------------*/
void CmdLCD(u8 cmd)
{
    IOCLR0 = (1 << RS);   // RS = 0 ? Command mode
    DispLCD(cmd);        // Send command to LCD
}

/*---------------- SEND DATA TO LCD ----------------*/
void CharLCD(u8 dat)
{
    IOSET0 = (1 << RS);   // RS = 1 ? Data mode
    DispLCD(dat);        // Send data to LCD
}

/*---------------- LOW-LEVEL LCD WRITE ----------------*/
void DispLCD(u8 val)
{
    IOCLR0 = (1 << RW);        // RW = 0 ? Write operation

    IOCLR1 = LCD_DAT;         // Clear previous data
    IOSET1 = ((u32)val << 16); // Place new data on P1.16�P1.23

    IOSET0 = (1 << EN);       // EN = 1 ? Latch data
    delay_ms(2);
    IOCLR0 = (1 << EN);       // EN = 0 ? Complete write
    delay_ms(2);
}

/*---------------- DISPLAY STRING ----------------*/
void StrLCD(u8 *ptr)
{
    while (*ptr)             // Loop until NULL character
        CharLCD(*ptr++);    // Send each character
}

/*---------------- DISPLAY INTEGER ----------------*/
void IntLCD(s32 num)
{
    u8 buf[10];   // Buffer for digits
    s8 i = 0;

    if (num == 0)
    {
        CharLCD('0');       // Handle zero
        return;
    }

    if (num < 0)
    {
        CharLCD('-');       // Handle negative number
        num = -num;
    }

    /* Convert number to string (reverse order) */
    while (num)
    {
        buf[i++] = (num % 10) + '0';
        num /= 10;
    }

    /* Display digits in correct order */
    while (--i >= 0)
        CharLCD(buf[i]);
}

/*---------------- DISPLAY FLOAT (2 DECIMALS) ----------------*/
void FltLCD(f32 val)
{
    s32 ip;
    f32 fp;
    u8 i, d;

    if (val < 0)
    {
        CharLCD('-');
        val = -val;
    }

    ip = (s32)val;   // Integer part
    IntLCD(ip);

    CharLCD('.');    // Decimal point

    fp = val - ip;   // Fractional part

    for (i = 0; i < 2; i++)
    {
        fp *= 10;
        d = (u8)fp;
        CharLCD(d + '0');
        fp -= d;
    }
}

/*---------------- STORE CUSTOM CHARACTER ----------------*/
void StoreCustCharFont(void)
{
    u8 i;

    /* Custom character pattern (example: arrow shape) */
    u8 LUT[8] = {0x00,0x00,0x04,0x0C,0x1C,0x1C,0x1C,0x00};

    CmdLCD(0x40);   // Set CGRAM address to 0

    for (i = 0; i < 8; i++)
        CharLCD(LUT[i]);   // Store character in CGRAM

    CmdLCD(0x80);   // Return to DDRAM (normal display)
}
