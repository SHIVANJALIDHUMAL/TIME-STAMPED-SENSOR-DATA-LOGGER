#include"types.h"        // Custom data types like u32, f32
#include<LPC21xx.h>     // LPC21xx MCU register definitions
#include"delay.h"       // Delay functions
#include"adc_defines.h" // ADC pin and bit definitions

/*------------------------------------------------
  ADC Initialization (single channel version)
------------------------------------------------*/

/*void Init_ADC(void)
{
	// Configure P0.27 to P0.30 as AIN0�AIN3 pins
	PINSEL1 &= ~(255<<22);
	PINSEL1 |= AIN0_PIN_0_27;

	// Configure ADC Control Register:
	// Power up ADC and set clock divider
	ADCR |= (1<<PDN_BIT) | (CLKDIV<<CLKDIV_BITS);
}*/

/*------------------------------------------------
  ADC Initialization with Channel Selection
------------------------------------------------*/
void Init_ADC(int chNo)
{
	// Clear previous AIN pin selection for P0.27�P0.30
	PINSEL1 &= ~chNo;

	// Configure selected pin as ADC input
	PINSEL1 |= chNo;

	// Configure ADC Control Register:
	// Power up ADC and set clock divider
	ADCR |= (1<<PDN_BIT) | (CLKDIV<<CLKDIV_BITS);
}


/*u32 chSelNo[4] = { AIN0_PIN_0_27, 
	                 AIN1_PIN_0_28,
	                 AIN2_PIN_0_29,
	                 AIN3_PIN_0_30};

									 
void Init_ADC(int chNo)
{
	// Clear previous ADC pin selection
	PINSEL1 &= ~(chSelNo[chNo]);

	// Configure selected ADC pin
	PINSEL1 |= chSelNo[chNo];

	// Power up ADC and set clock divider
	ADCR |= (1<<PDN_BIT) | (CLKDIV<<CLKDIV_BITS);
} */


/*------------------------------------------------
  Read ADC Channel and Convert to Voltage
------------------------------------------------*/
void Read_ADC(u32 chNo, f32 *eAR, u32 *adcDVal)
{
	// Clear any previous channel selection bits
	ADCR &= 0XFFFFFF00;

	// Select requested channel and start conversion
	ADCR |= ((1<<ADC_CONV_START_BIT) | (1<<chNo));

	// Wait for ADC conversion time
	delay_us(3);

	// Wait until conversion is complete (DONE bit = 1)
	while(((ADDR >> DONE_BIT) & 1) == 0);

	// Stop ADC conversion
	ADCR &= ~(1<<ADC_CONV_START_BIT);

	// Read 10-bit digital ADC value
	*adcDVal = ((ADDR >> DIGITAL_DATA_BITS) & 1023);

	// Convert digital value to voltage (0�3.3V range)
	*eAR = *adcDVal * (3.3 / 1023);
}
