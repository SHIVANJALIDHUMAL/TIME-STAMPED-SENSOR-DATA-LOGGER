#include <LPC21xx.h>     // LPC21xx register definitions
#include "types.h"      // Custom data types like u8, u32, s8, f32
#include "defines.h"    // Macros like READBIT()

/*-----------------------------------------
  UART0 Initialization Function
-----------------------------------------*/
void InitUART(void)
{
    /* Configure P0.0 as TXD0 and P0.1 as RXD0 */
    PINSEL0 &= ~((3UL << 0) | (3UL << 2));   // Clear bits for P0.0 and P0.1
    PINSEL0 |=  ((1UL << 0) | (1UL << 2));   // Set alternate function for UART0

    /* Set UART frame format and enable divisor latch */
    U0LCR = 0x83;     // 8-bit data, 1 stop bit, no parity, DLAB = 1

    /* Set baud rate = 9600 @ 60 MHz
       Baud Divisor = PCLK / (16 * Baud) = 60MHz / (16 * 9600) � 391 */
    U0DLL = 97;       // Low byte of divisor
    U0DLM = 0;        // High byte of divisor

    /* Lock divisor by clearing DLAB */
    U0LCR = 0x03;     // 8-bit, 1 stop, no parity, DLAB = 0
}

/*-----------------------------------------
  Transmit One Character via UART0
-----------------------------------------*/
void UARTTxChar(s8 ch)
{
    while(!READBIT(U0LSR,5));  // Wait until THR (Transmit Holding Register) is empty
    U0THR = ch;               // Load character into transmit register
}

/*-----------------------------------------
  Receive One Character from UART0
-----------------------------------------*/
s8 UARTRxChar(void)
{
    while(!READBIT(U0LSR,0));  // Wait until data is available in RBR
    return U0RBR;             // Read received character
}

/*-----------------------------------------
  Transmit a String via UART0
-----------------------------------------*/
void UARTTxStr(const char *ptr)
{
    while(*ptr)              // Loop until null character
        UARTTxChar(*ptr++); // Send each character
}

/*-----------------------------------------
  Transmit Unsigned 32-bit Integer via UART0
-----------------------------------------*/
void UARTTxu32(u32 num)
{
    u8 buf[10];  // Buffer to store digits
    u8 i = 0;

    if(num == 0)
    {
        UARTTxChar('0');  // If number is zero, send '0'
        return;
    }

    /* Convert number to string (reverse order) */
    while(num)
    {
        buf[i++] = (num % 10) + '0'; // Extract last digit
        num /= 10;
    }

    /* Transmit digits in correct order */
    while(i--)
        UARTTxChar(buf[i]);
}

/*-----------------------------------------
  Transmit Float (6 decimal places) via UART0
-----------------------------------------*/
void UARTTxF32(f32 fnum)
{
    u32 int_part;
    u8 i;

    /* Handle negative numbers */
    if(fnum < 0)
    {
        UARTTxChar('-');
        fnum = -fnum;
    }

    /* Send integer part */
    int_part = (u32)fnum;
    UARTTxu32(int_part);
    UARTTxChar('.');   // Decimal point

    /* Send fractional part (6 digits) */
    for(i = 0; i < 6; i++)
    {
        fnum = (fnum - int_part) * 10;  // Shift next decimal digit
        int_part = (u32)fnum;
        UARTTxChar(int_part + '0');
    }
}
