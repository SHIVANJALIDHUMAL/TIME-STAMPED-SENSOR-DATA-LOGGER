#include"types.h"
void InitUART(void);
void UARTTxChar(s8);
void UARTTxStr(const char*);
s8 UARTRxChar(void);

void UARTTxu32(u32 num);
void UARTTxf32(f32 fnum);



